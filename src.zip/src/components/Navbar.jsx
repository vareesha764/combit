import { Link } from "react-router-dom";
import useAuth from "../hooks/useAuth";

export default function Navbar() {
    const { user, logout } = useAuth();

    return (
        <nav className="flex justify-between px-6 py-3 shadow">
            <Link to="/" className="font-bold text-xl">
                Study Circle
            </Link>

            <div className="flex gap-4">
                {!user ? (
                    <>
                        <Link to="/login">Login</Link>
                        <Link to="/register">Register</Link>
                    </>
                ) : (
                    <>
                        <span>{user?.name}</span>
                        <button onClick={logout} className="text-red-500">
                            Logout
                        </button>
                    </>
                )}
            </div>
        </nav>
    );
}
