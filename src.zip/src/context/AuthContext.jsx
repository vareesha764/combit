import { createContext, useState, useEffect } from "react";
import API from "../services/api";

export const AuthContext = createContext();

export default function AuthProvider({ children }) {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (token) loadUser();
    }, []);

    const loadUser = async () => {
        try {
            const res = await API.get("/users/me");
            setUser(res.data);
        } catch {
            setUser(null);
        }
    };

    const login = async (email, password) => {
        console.log("➡ Calling → /auth/login");
        const res = await API.post("/auth/login", { email, password });
        localStorage.setItem("token", res.data.token);
        await loadUser();
    };

    const registerUser = async (data) => {
        console.log("➡ Calling → /auth/register");
        const res = await API.post("/auth/register", data);
        localStorage.setItem("token", res.data.token);
        await loadUser();
        alert("REGISTER FUNCTION CALLED");
    };

    const logout = () => {
        localStorage.removeItem("token");
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, register: registerUser, logout }}>
            {children}
        </AuthContext.Provider>
    );
}
