import { useState } from "react";
import useAuth from "../hooks/useAuth";

export default function Register() {
    const { register } = useAuth();

    const [form, setForm] = useState({
        name: "",
        email: "",
        password: "",
    });

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await register(form);
            console.log("✅ Registered successfully");
        } catch (err) {
            console.log("Register error:", err);
        }
    };

    return (
        <div className="flex justify-center items-center min-h-screen">
            <form
                onSubmit={handleSubmit}
                className="bg-white shadow rounded p-6 w-80"
            >
                <h2 className="text-xl font-bold mb-4">Register</h2>

                <input
                    type="text"
                    className="border p-2 w-full mb-3"
                    placeholder="Name"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                />

                <input
                    type="email"
                    className="border p-2 w-full mb-3"
                    placeholder="Email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                />

                <input
                    type="password"
                    className="border p-2 w-full mb-3"
                    placeholder="Password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                />

                <button
                    type="submit"
                    className="bg-green-600 text-white py-2 w-full rounded"
                >
                    Register
                </button>
            </form>
        </div>
    );
}
